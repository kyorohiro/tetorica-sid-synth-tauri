// SPDX-License-Identifier: BSD-3-Clause
// Glue for the shared Code editor/scheduler and this Synth's existing SID.
import {createPlaygroundCodeRuntime} from '../js/playground_code_runtime.js?v=ps1-vab-api-1';
import {setupSynthCodeControls} from '../synth/synth_code_controls.js?v=huc-working-saved-1';
import {selectSidCodeDeclarations} from './code_declarations.js?sid-code=1';
import {createSidCodeAudio} from './code_audio.js?sid-code=1';
import {createSidCodeProject,SID_PROJECT_FILE_BYTES} from './code_project.js?v=sid-working-saved-1';
import {setupSidCodeFiles} from './code_files.js?v=sid-working-saved-1';
import {SID_TIMED_EXAMPLES} from './code_examples.js';

export const SID_STARTER_CODE=`const sid = await useSoundChip("sid");
setBpm(120);

await sid.setVoice(CH1, {
  waveform: "saw",
  sync: true,
  ring: true,
  test: false,
});

// CH1の変調源はCH3。音は直接出さず、発振器を使います。
await sid.setVoice(CH3, {
  waveform: "triangle",
  sync: false,
  ring: false,
  test: false,
});
await sid.noteOff(CH3);

await sid.setFilter({
  mode: "lowpass+bandpass",
  routing: 1,          // CH1をFilterへ
  cutoff: 100,
  voice3off: true,     // CH3の直接出力を消す
});

// 各ループが共有する状態。Applyでも保持します。
const motion = await livePrepare("sid-motion", () => ({
  hz: 110,
  ratio: 0.2,
}));

// メロディ：0.25拍ごとに次の音へ
liveLoop("melody", async () => {
  const notes = scale("E2", "minorPentatonic", 1);
  motion.hz = await sid.setNote(CH1, choose(notes));

  // 新しい音程へ、現在の変調比を反映
  await sid.setFrequency(CH3, motion.hz * motion.ratio);
  await sid.keyOn(CH1);

  await beat(0.2);
  await sid.noteOff(CH1);
  await beat(0.05);
});

// 変調比：2秒で 0.2 → 0.8 → 0.2
liveLoop("modulation", async () => {
  await tween(2, async (p) => {
    const wave = (1 - Math.cos(p * Math.PI * 2)) / 2;
    motion.ratio = 0.2 + 0.6 * wave;

    await sid.setFrequency(CH3, motion.hz * motion.ratio);
  });
});

// Filter：4秒で 100 → 600 → 100
liveLoop("filter", async () => {
  await tween(4, async (p) => {
    const wave = (1 - Math.cos(p * Math.PI * 2)) / 2;
    await sid.setFilter({
      cutoff: Math.round(100 + 500 * wave),
    });
  });
});
`;
const aborted=()=>new DOMException('SID Code stopped','AbortError');
export function setupSidCodeHost({ensureAudio,getAudio,getSettings,getSaveSoundSettings=getSettings,applySettings,stopKeyboard,stopSong,
  beforeSoundApply=stopSong,beforeRun=async()=>{},prepareOutput=async()=>{},onActivity=()=>{},onViewChange=()=>{},onExpandedChange=()=>{},setStatus=()=>{}}={}) {
  let disposed=false,epoch=0,modeEpoch=0,runtime=null,controls=null,files=null;
  const project=createSidCodeProject({settings:getSettings(),getStarterCode:()=>SID_STARTER_CODE,starterFiles:SID_TIMED_EXAMPLES});
  const audio=createSidCodeAudio({ensureReady:ensureAudio,getAudio,onLog:line=>controls?.appendLog(line)});
  const valid=token=>{if(disposed||token!==epoch)throw aborted();};
  function openOutput(){
    const state=runtime?.getState();
    if(disposed||state?.running||state?.busy||state?.stopping)return false;
    audio.open();return true;
  }
  async function stop() {
    const request=++modeEpoch;
    if(controls)await controls.stop();else if(runtime)await runtime.stop();
    // A newer Run or mode request owns its own output gate. Idle manual
    // performance is available in either view after cleanup has completed.
    if(!disposed&&request===modeEpoch&&!runtime?.getState().running)audio.open();
    onActivity();
  }
  files=setupSidCodeFiles({project,getSettings,getSaveSoundSettings,applySettings,setStatus,
    async onBeforeSoundApply(){await beforeSoundApply();if(!runtime?.getState().running)await stopKeyboard();},
    async onBeforeWorkspaceReplace(){await stop();await stopSong();await stopKeyboard();}});
  function getRuntime() {
    if(runtime)return runtime;
    runtime=createPlaygroundCodeRuntime({supportedSoundChips:['sid'],
      async ensureReady(){
        const token=epoch;await ensureAudio();valid(token);
        await audio.prepare();valid(token);
        const owner=getAudio();
        await prepareOutput(owner,()=>!disposed&&token===epoch&&owner===getAudio());valid(token);
        audio.open();onActivity();
      },
      now:()=>getAudio()?.context.currentTime??0,
      useSoundChip:name=>audio.useSoundChip(name),fx:audio.fx,
      readFile:(...args)=>project.readSavedFile(...args),prepareSource:(...args)=>project.prepareSavedSource(...args),
      onLog:line=>controls?.appendLog(line),onState:state=>{controls?.setRuntimeState(state);onActivity();},
      beforeStopSoundChips(){epoch++;return audio.beforeStop();},
      async stopSoundChips(){
        const token=epoch,engine=getAudio();
        await audio.stop();
        // Retire a gesture-created engine which has not yet been adopted.
        // This runs after the output fade for any existing performance.
        if(!getAudio())await stopKeyboard();
        // The Code fade must not leave the restored author route closed to
        // new manual keys, whichever input view is selected.
        if(!disposed&&token===epoch&&getAudio()===engine&&!runtime?.getState().running)audio.open();
      },
    });
    return runtime;
  }
  controls=setupSynthCodeControls({project,files,getRuntime,
    keepRunningOnKeyboard:true,persistentExpanded:true,
    allowTextFiles:true,maxTextLength:SID_PROJECT_FILE_BYTES,writeText:(path,source)=>project.writeEditorText(path,source),
    editorChip:'c64',transformDeclarations:selectSidCodeDeclarations,
    journalKey:'tetorica-sid-synth-pending-code',getStarterCode:()=>SID_STARTER_CODE,
    async onBeforeRun(){
      modeEpoch++;await stopSong();
      if(!runtime?.getState().running)await stopKeyboard();
      await beforeRun();
    },
    async onModeChange(){
      modeEpoch++;openOutput();
      onActivity();
    },onViewChange,onExpandedChange,setStatus,
  });
  const ready=controls.ready.then(()=>{
    if(!disposed)try{project.ensureStarterFiles();}catch(error){setStatus(`Examples were not added: ${error.message}`);}
  });
  return {project,files,controls,ready,
    isCodeMode:()=>controls.isCodeMode(),isRunning:()=>Boolean(runtime?.getState().running),
    getState:()=>runtime?.getState()??{state:'idle',running:false},
    stop,openOutput,markSoundDirty:(value)=>files.markSoundDirty(value),
    async dispose(){if(disposed)return;await stop();disposed=true;epoch++;controls.dispose();await files.dispose();await audio.dispose();},
  };
}
